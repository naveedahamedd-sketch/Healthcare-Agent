﻿Healthcare Agent local package

1. Extract this ZIP.
2. Open launch_app.cmd on Windows to use the browser app from localhost.
3. The front page opens first. Use Login on Web or Use Local Mode to enter the workspace.
4. The Python agent model is included in healthcare_agent/.
5. For developer checks, install requirements and run: python -m pytest -q
6. For the Streamlit demo, run: streamlit run streamlit_app.py
